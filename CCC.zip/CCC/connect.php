<?php
// Collect POST data
$name = $_POST['name'];
$email = $_POST['email'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$advice = $_POST['advice'];
$response = $_POST['response'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'ccc');

// Check connection
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// Prepare the SQL statement
$stmt = $conn->prepare("INSERT INTO response ( name, email, age, gender, advice, response) 
VALUES (?, ?, ?, ?, ?, ?)");
if ($stmt === false) {
    die("MySQL prepare statement failed: " . $conn->error);
}

// Bind parameters (adjusting types as needed)
$stmt->bind_param("ssisss", $name, $email, $age, $gender, $advice, $response);

// Execute the statement
$execval = $stmt->execute();

// Check execution result
if ($execval) {
    header("Location: thank-you.html");
	exit();
} else {
    header("Location: error.html");
}

// Close statement and connection
$stmt->close();
$conn->close();
?>